# AI-vs-IQ
GUESS THE COMPUTER'S NUMBER
COMMITTED OCT2TUES
Click here to play this game: https://drjwebsitedesign.github.io/SaaS_IQ-vs-AI/
